package com.meridian.platform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MeridianPlatformApplication {

	public static void main(String[] args) {
		SpringApplication.run(MeridianPlatformApplication.class, args);
	}

}
